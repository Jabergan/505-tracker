//#region node_modules/.nitro/vite/services/ssr/assets/types-D9sHnxZK.js
var CATEGORY_KINDS = [
	"land",
	"soft",
	"hard",
	"contingency"
];
var PAYMENT_METHODS = [
	"check",
	"ach",
	"wire",
	"card",
	"cash",
	"retainage"
];
var CO_STATUSES = [
	"pending",
	"approved",
	"rejected"
];
//#endregion
export { CO_STATUSES as n, PAYMENT_METHODS as r, CATEGORY_KINDS as t };
