import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { n as CO_STATUSES, r as PAYMENT_METHODS, t as CATEGORY_KINDS } from "./types-D9sHnxZK.mjs";
import { a as string, i as object, r as number, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-BaTDdgVe.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var _0002_tracker_default = "create table if not exists job (\n  id text primary key,\n  name text not null,\n  address text not null,\n  city text not null default '',\n  beds integer not null default 0,\n  baths_tenths integer not null default 0,\n  sqft integer not null default 0,\n  stories integer not null default 1,\n  land_cost_cents bigint not null default 0,\n  target_sale_cents bigint not null default 0,\n  start_date date,\n  target_close_date date,\n  notes text not null default '',\n  updated_at timestamptz not null default now()\n);\n\ncreate table if not exists categories (\n  id text primary key,\n  name text not null,\n  sort_order integer not null,\n  kind text not null\n);\n\ncreate table if not exists line_items (\n  id serial primary key,\n  category_id text not null references categories(id),\n  name text not null,\n  vendor text not null default '',\n  original_budget_cents bigint not null default 0,\n  committed_cents bigint not null default 0,\n  actual_cents bigint not null default 0,\n  pct_complete integer not null default 0,\n  notes text not null default '',\n  sort_order integer not null default 0,\n  created_at timestamptz not null default now()\n);\n\ncreate index if not exists line_items_category_idx on line_items (category_id, sort_order, id);\n\ncreate table if not exists payments (\n  id serial primary key,\n  line_item_id integer not null references line_items(id) on delete cascade,\n  paid_on date not null,\n  amount_cents bigint not null,\n  payee text not null default '',\n  method text not null default 'check',\n  memo text not null default '',\n  created_at timestamptz not null default now()\n);\n\ncreate index if not exists payments_item_idx on payments (line_item_id);\ncreate index if not exists payments_paid_on_idx on payments (paid_on desc);\n\ncreate table if not exists change_orders (\n  id serial primary key,\n  line_item_id integer references line_items(id) on delete set null,\n  title text not null,\n  amount_cents bigint not null,\n  status text not null default 'pending',\n  reason text not null default '',\n  created_at timestamptz not null default now()\n);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_tracker.sql": _0002_tracker_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
var SEED_JOB = {
	id: "505",
	name: "505 Spec House",
	address: "505 Maple Street",
	city: "Westfield",
	beds: 4,
	bathsTenths: 25,
	sqft: 2240,
	stories: 2,
	landCostCents: 925e4,
	targetSaleCents: 675e5,
	startDate: "2026-03-12",
	targetCloseDate: "2026-12-18",
	notes: "Spec two-story. Closed the lot in March. Framing is up; roof dry-in next. Watch lumber and windows — both already over."
};
var SEED_CATEGORIES = [
	{
		id: "land",
		name: "Land",
		sortOrder: 10,
		kind: "land"
	},
	{
		id: "soft",
		name: "Soft costs",
		sortOrder: 20,
		kind: "soft"
	},
	{
		id: "site",
		name: "Site work",
		sortOrder: 30,
		kind: "hard"
	},
	{
		id: "foundation",
		name: "Foundation",
		sortOrder: 40,
		kind: "hard"
	},
	{
		id: "framing",
		name: "Framing",
		sortOrder: 50,
		kind: "hard"
	},
	{
		id: "envelope",
		name: "Envelope",
		sortOrder: 60,
		kind: "hard"
	},
	{
		id: "mep",
		name: "MEP",
		sortOrder: 70,
		kind: "hard"
	},
	{
		id: "interior",
		name: "Interior",
		sortOrder: 80,
		kind: "hard"
	},
	{
		id: "kitchen",
		name: "Kitchen & baths",
		sortOrder: 90,
		kind: "hard"
	},
	{
		id: "final",
		name: "Final & site finish",
		sortOrder: 100,
		kind: "hard"
	},
	{
		id: "contingency",
		name: "Contingency",
		sortOrder: 110,
		kind: "contingency"
	}
];
var SEED_ITEMS = [
	{
		id: 1,
		categoryId: "land",
		name: "Lot purchase",
		vendor: "Westfield Title",
		original: 92500,
		committed: 92500,
		actual: 92500,
		pct: 100,
		notes: "Closed 12 Mar."
	},
	{
		id: 2,
		categoryId: "soft",
		name: "Plans & architecture",
		vendor: "Northline Studio",
		original: 8500,
		committed: 8500,
		actual: 8500,
		pct: 100,
		notes: "Permit set complete."
	},
	{
		id: 3,
		categoryId: "soft",
		name: "Permits & impact fees",
		vendor: "City of Westfield",
		original: 12400,
		committed: 12400,
		actual: 12400,
		pct: 100,
		notes: ""
	},
	{
		id: 4,
		categoryId: "soft",
		name: "Survey & engineering",
		vendor: "Hale Civil",
		original: 4200,
		committed: 4200,
		actual: 4200,
		pct: 100,
		notes: "Includes soil report."
	},
	{
		id: 5,
		categoryId: "soft",
		name: "Builder's risk & liability",
		vendor: "Summit Mutual",
		original: 6100,
		committed: 6100,
		actual: 6100,
		pct: 100,
		notes: "Policy through close."
	},
	{
		id: 6,
		categoryId: "soft",
		name: "Construction loan interest",
		vendor: "First Regional",
		original: 9800,
		committed: 0,
		actual: 3200,
		pct: 35,
		notes: "Accrues until sale."
	},
	{
		id: 7,
		categoryId: "soft",
		name: "Utility tap fees",
		vendor: "Westfield Utilities",
		original: 5400,
		committed: 5400,
		actual: 5400,
		pct: 100,
		notes: ""
	},
	{
		id: 8,
		categoryId: "site",
		name: "Clearing, trees, grading",
		vendor: "Red Clay Excavating",
		original: 11800,
		committed: 11800,
		actual: 11240,
		pct: 100,
		notes: "Came in under."
	},
	{
		id: 9,
		categoryId: "site",
		name: "Driveway base & sidewalks",
		vendor: "Red Clay Excavating",
		original: 9200,
		committed: 9200,
		actual: 9200,
		pct: 100,
		notes: "Finish coat later."
	},
	{
		id: 10,
		categoryId: "site",
		name: "Sewer tap & laterals",
		vendor: "Pike Plumbing",
		original: 7400,
		committed: 7400,
		actual: 7400,
		pct: 100,
		notes: ""
	},
	{
		id: 11,
		categoryId: "site",
		name: "Water & electric service",
		vendor: "Westfield Utilities",
		original: 5600,
		committed: 5600,
		actual: 5360,
		pct: 100,
		notes: ""
	},
	{
		id: 12,
		categoryId: "foundation",
		name: "Excavation",
		vendor: "Red Clay Excavating",
		original: 4800,
		committed: 4800,
		actual: 4800,
		pct: 100,
		notes: ""
	},
	{
		id: 13,
		categoryId: "foundation",
		name: "Footings & walls",
		vendor: "Keystone Concrete",
		original: 28600,
		committed: 32250,
		actual: 32250,
		pct: 100,
		notes: "Revised after soil report."
	},
	{
		id: 14,
		categoryId: "foundation",
		name: "Waterproofing & drain tile",
		vendor: "Keystone Concrete",
		original: 3200,
		committed: 3200,
		actual: 3100,
		pct: 100,
		notes: ""
	},
	{
		id: 15,
		categoryId: "foundation",
		name: "Termite & moisture",
		vendor: "Harbor Pest",
		original: 1100,
		committed: 1100,
		actual: 1100,
		pct: 100,
		notes: ""
	},
	{
		id: 16,
		categoryId: "framing",
		name: "Lumber package",
		vendor: "ABC Building Supply",
		original: 41200,
		committed: 42800,
		actual: 42800,
		pct: 100,
		notes: "Framing lumber ran hot."
	},
	{
		id: 17,
		categoryId: "framing",
		name: "Framing labor",
		vendor: "Calder Crew",
		original: 24800,
		committed: 24800,
		actual: 14e3,
		pct: 70,
		notes: "Standing walls; stairs left."
	},
	{
		id: 18,
		categoryId: "framing",
		name: "Roof trusses",
		vendor: "Peak Truss",
		original: 8900,
		committed: 8900,
		actual: 8900,
		pct: 100,
		notes: "Set 22 Aug."
	},
	{
		id: 19,
		categoryId: "framing",
		name: "Hardware & hangers",
		vendor: "ABC Building Supply",
		original: 2100,
		committed: 2100,
		actual: 1800,
		pct: 90,
		notes: ""
	},
	{
		id: 20,
		categoryId: "envelope",
		name: "Roofing",
		vendor: "Ridge Roofing",
		original: 16400,
		committed: 16400,
		actual: 4e3,
		pct: 20,
		notes: "Deposit; dry-in scheduled."
	},
	{
		id: 21,
		categoryId: "envelope",
		name: "Siding & exterior trim",
		vendor: "North Face Exteriors",
		original: 22100,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: "James Hardie, evening steel."
	},
	{
		id: 22,
		categoryId: "envelope",
		name: "Windows",
		vendor: "Clearview Supply",
		original: 18600,
		committed: 20440,
		actual: 6200,
		pct: 30,
		notes: "Deposit + stair window CO."
	},
	{
		id: 23,
		categoryId: "envelope",
		name: "Exterior doors",
		vendor: "Clearview Supply",
		original: 4200,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 24,
		categoryId: "envelope",
		name: "Gutters & downspouts",
		vendor: "Ridge Roofing",
		original: 1800,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 25,
		categoryId: "envelope",
		name: "Garage door",
		vendor: "DoorWorks",
		original: 2400,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 26,
		categoryId: "mep",
		name: "Plumbing rough & trim",
		vendor: "Pike Plumbing",
		original: 24800,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: "Rough after dry-in."
	},
	{
		id: 27,
		categoryId: "mep",
		name: "HVAC",
		vendor: "Climate Right",
		original: 21400,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: "2-ton + 3-ton split."
	},
	{
		id: 28,
		categoryId: "mep",
		name: "Electrical",
		vendor: "Arc & Co.",
		original: 19600,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 29,
		categoryId: "mep",
		name: "Low voltage",
		vendor: "Arc & Co.",
		original: 2400,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: "Prewire only."
	},
	{
		id: 30,
		categoryId: "interior",
		name: "Insulation",
		vendor: "Blanket Insulation",
		original: 7800,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 31,
		categoryId: "interior",
		name: "Drywall",
		vendor: "Plainfield Walls",
		original: 14200,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 32,
		categoryId: "interior",
		name: "Interior paint",
		vendor: "Hearth Paint",
		original: 6800,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 33,
		categoryId: "interior",
		name: "Doors, casing, base",
		vendor: "Millwork House",
		original: 9200,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 34,
		categoryId: "interior",
		name: "Flooring",
		vendor: "Grain & Plank",
		original: 18400,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: "White oak, 5 inch."
	},
	{
		id: 35,
		categoryId: "interior",
		name: "Tile",
		vendor: "Grain & Plank",
		original: 6400,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 36,
		categoryId: "kitchen",
		name: "Cabinets",
		vendor: "Linea Cabinets",
		original: 16800,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: "Shaker, painted."
	},
	{
		id: 37,
		categoryId: "kitchen",
		name: "Countertops",
		vendor: "Stonebench",
		original: 7200,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: "Quartz upgrade pending."
	},
	{
		id: 38,
		categoryId: "kitchen",
		name: "Appliances",
		vendor: "Harbor Appliance",
		original: 9400,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: "Package quote held 60 days."
	},
	{
		id: 39,
		categoryId: "kitchen",
		name: "Bath vanities & fixtures",
		vendor: "Pike Plumbing",
		original: 8100,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 40,
		categoryId: "kitchen",
		name: "Shower glass",
		vendor: "Clearview Supply",
		original: 2100,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 41,
		categoryId: "final",
		name: "Landscaping",
		vendor: "Greenward",
		original: 9800,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: "Sod + 8 trees."
	},
	{
		id: 42,
		categoryId: "final",
		name: "Final clean & punch",
		vendor: "Turnover Crew",
		original: 2400,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: ""
	},
	{
		id: 43,
		categoryId: "final",
		name: "Staging",
		vendor: "Show House",
		original: 1800,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: "Two-week listing set."
	},
	{
		id: 44,
		categoryId: "final",
		name: "Dumpsters, toilets, misc",
		vendor: "Job site",
		original: 3200,
		committed: 1800,
		actual: 1640,
		pct: 50,
		notes: "Running monthly."
	},
	{
		id: 45,
		categoryId: "contingency",
		name: "Job contingency",
		vendor: "",
		original: 28e3,
		committed: 0,
		actual: 0,
		pct: 0,
		notes: "Do not spend without a CO."
	}
];
var SEED_PAYMENTS = [
	{
		itemId: 1,
		paidOn: "2026-03-12",
		amount: 92500,
		payee: "Westfield Title",
		method: "wire",
		memo: "Lot closing"
	},
	{
		itemId: 2,
		paidOn: "2026-03-18",
		amount: 4250,
		payee: "Northline Studio",
		method: "check",
		memo: "Retainer"
	},
	{
		itemId: 2,
		paidOn: "2026-04-22",
		amount: 4250,
		payee: "Northline Studio",
		method: "check",
		memo: "Permit set"
	},
	{
		itemId: 4,
		paidOn: "2026-03-28",
		amount: 4200,
		payee: "Hale Civil",
		method: "ach",
		memo: "Survey + soils"
	},
	{
		itemId: 3,
		paidOn: "2026-04-30",
		amount: 12400,
		payee: "City of Westfield",
		method: "check",
		memo: "Building permit"
	},
	{
		itemId: 5,
		paidOn: "2026-05-02",
		amount: 6100,
		payee: "Summit Mutual",
		method: "ach",
		memo: "Builder's risk"
	},
	{
		itemId: 7,
		paidOn: "2026-05-08",
		amount: 5400,
		payee: "Westfield Utilities",
		method: "check",
		memo: "Taps"
	},
	{
		itemId: 8,
		paidOn: "2026-05-14",
		amount: 11240,
		payee: "Red Clay Excavating",
		method: "check",
		memo: "Clear / grade"
	},
	{
		itemId: 12,
		paidOn: "2026-05-20",
		amount: 4800,
		payee: "Red Clay Excavating",
		method: "check",
		memo: "Foundation dig"
	},
	{
		itemId: 9,
		paidOn: "2026-05-28",
		amount: 9200,
		payee: "Red Clay Excavating",
		method: "check",
		memo: "Drive base"
	},
	{
		itemId: 10,
		paidOn: "2026-06-04",
		amount: 7400,
		payee: "Pike Plumbing",
		method: "check",
		memo: "Sewer lateral"
	},
	{
		itemId: 11,
		paidOn: "2026-06-06",
		amount: 5360,
		payee: "Westfield Utilities",
		method: "ach",
		memo: "Service"
	},
	{
		itemId: 13,
		paidOn: "2026-06-18",
		amount: 16e3,
		payee: "Keystone Concrete",
		method: "check",
		memo: "Footings draw 1"
	},
	{
		itemId: 13,
		paidOn: "2026-07-02",
		amount: 16250,
		payee: "Keystone Concrete",
		method: "check",
		memo: "Walls + CO"
	},
	{
		itemId: 14,
		paidOn: "2026-07-08",
		amount: 3100,
		payee: "Keystone Concrete",
		method: "check",
		memo: "Damp-proof"
	},
	{
		itemId: 15,
		paidOn: "2026-07-09",
		amount: 1100,
		payee: "Harbor Pest",
		method: "card",
		memo: "Pretreatment"
	},
	{
		itemId: 16,
		paidOn: "2026-07-22",
		amount: 2e4,
		payee: "ABC Building Supply",
		method: "check",
		memo: "Lumber deposit"
	},
	{
		itemId: 16,
		paidOn: "2026-08-04",
		amount: 22800,
		payee: "ABC Building Supply",
		method: "check",
		memo: "Lumber balance"
	},
	{
		itemId: 18,
		paidOn: "2026-08-12",
		amount: 8900,
		payee: "Peak Truss",
		method: "check",
		memo: "Truss package"
	},
	{
		itemId: 17,
		paidOn: "2026-08-20",
		amount: 8e3,
		payee: "Calder Crew",
		method: "check",
		memo: "Framing draw 1"
	},
	{
		itemId: 17,
		paidOn: "2026-09-03",
		amount: 6e3,
		payee: "Calder Crew",
		method: "check",
		memo: "Framing draw 2"
	},
	{
		itemId: 19,
		paidOn: "2026-08-26",
		amount: 1800,
		payee: "ABC Building Supply",
		method: "card",
		memo: "Hangers"
	},
	{
		itemId: 20,
		paidOn: "2026-09-02",
		amount: 4e3,
		payee: "Ridge Roofing",
		method: "check",
		memo: "Roof deposit"
	},
	{
		itemId: 22,
		paidOn: "2026-08-28",
		amount: 6200,
		payee: "Clearview Supply",
		method: "check",
		memo: "Window deposit"
	},
	{
		itemId: 6,
		paidOn: "2026-06-30",
		amount: 1600,
		payee: "First Regional",
		method: "ach",
		memo: "June interest"
	},
	{
		itemId: 6,
		paidOn: "2026-07-31",
		amount: 1600,
		payee: "First Regional",
		method: "ach",
		memo: "July interest"
	},
	{
		itemId: 44,
		paidOn: "2026-05-16",
		amount: 820,
		payee: "Roll-Off Co",
		method: "card",
		memo: "Dumpster 1"
	},
	{
		itemId: 44,
		paidOn: "2026-07-16",
		amount: 820,
		payee: "Roll-Off Co",
		method: "card",
		memo: "Dumpster 2"
	}
];
var SEED_COS = [
	{
		itemId: 13,
		title: "Deeper footings at rear",
		amount: 3650,
		status: "approved",
		reason: "Soils report required extra depth along the downhill wall."
	},
	{
		itemId: 22,
		title: "Stairwell window add",
		amount: 1840,
		status: "approved",
		reason: "Light well on the stair — sells the hall."
	},
	{
		itemId: 37,
		title: "Quartz upgrade",
		amount: 2200,
		status: "pending",
		reason: "Calacatta-look vs builder granite. Decide before template."
	},
	{
		itemId: 39,
		title: "Drop soaker tub",
		amount: -800,
		status: "approved",
		reason: "Primary bath: shower only. Credit the tub."
	}
];
function asKind(v) {
	return CATEGORY_KINDS.includes(v) ? v : "hard";
}
function asMethod(v) {
	return PAYMENT_METHODS.includes(v) ? v : "check";
}
function asCoStatus(v) {
	return CO_STATUSES.includes(v) ? v : "pending";
}
function mapJob(row) {
	return {
		id: row.id,
		name: row.name,
		address: row.address,
		city: row.city,
		beds: row.beds,
		bathsTenths: row.baths_tenths,
		sqft: row.sqft,
		stories: row.stories,
		landCostCents: Number(row.land_cost_cents),
		targetSaleCents: Number(row.target_sale_cents),
		startDate: row.start_date,
		targetCloseDate: row.target_close_date,
		notes: row.notes
	};
}
function mapCategory(row) {
	return {
		id: row.id,
		name: row.name,
		sortOrder: row.sort_order,
		kind: asKind(row.kind)
	};
}
function mapItem(row) {
	return {
		id: row.id,
		categoryId: row.category_id,
		name: row.name,
		vendor: row.vendor,
		originalBudgetCents: Number(row.original_budget_cents),
		committedCents: Number(row.committed_cents),
		actualCents: Number(row.actual_cents),
		pctComplete: row.pct_complete,
		notes: row.notes,
		sortOrder: row.sort_order
	};
}
function mapPayment(row) {
	return {
		id: row.id,
		lineItemId: row.line_item_id,
		paidOn: row.paid_on,
		amountCents: Number(row.amount_cents),
		payee: row.payee,
		method: asMethod(row.method),
		memo: row.memo
	};
}
function mapCo(row) {
	return {
		id: row.id,
		lineItemId: row.line_item_id,
		title: row.title,
		amountCents: Number(row.amount_cents),
		status: asCoStatus(row.status),
		reason: row.reason,
		createdAt: row.created_at
	};
}
async function ensureSeed() {
	const sql = await getSql();
	if (((await sql`select count(*)::int as c from job`)[0]?.c ?? 0) > 0) return;
	await sql.query(`insert into job (
      id, name, address, city, beds, baths_tenths, sqft, stories,
      land_cost_cents, target_sale_cents, start_date, target_close_date, notes
    ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`, [
		SEED_JOB.id,
		SEED_JOB.name,
		SEED_JOB.address,
		SEED_JOB.city,
		SEED_JOB.beds,
		SEED_JOB.bathsTenths,
		SEED_JOB.sqft,
		SEED_JOB.stories,
		SEED_JOB.landCostCents,
		SEED_JOB.targetSaleCents,
		SEED_JOB.startDate,
		SEED_JOB.targetCloseDate,
		SEED_JOB.notes
	]);
	for (const cat of SEED_CATEGORIES) await sql.query(`insert into categories (id, name, sort_order, kind) values ($1,$2,$3,$4)
       on conflict (id) do nothing`, [
		cat.id,
		cat.name,
		cat.sortOrder,
		cat.kind
	]);
	for (const item of SEED_ITEMS) await sql.query(`insert into line_items (
        id, category_id, name, vendor, original_budget_cents, committed_cents,
        actual_cents, pct_complete, notes, sort_order
      ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`, [
		item.id,
		item.categoryId,
		item.name,
		item.vendor,
		Math.round(item.original * 100),
		Math.round(item.committed * 100),
		Math.round(item.actual * 100),
		item.pct,
		item.notes,
		item.id
	]);
	for (const p of SEED_PAYMENTS) await sql.query(`insert into payments (line_item_id, paid_on, amount_cents, payee, method, memo)
       values ($1,$2,$3,$4,$5,$6)`, [
		p.itemId,
		p.paidOn,
		Math.round(p.amount * 100),
		p.payee,
		p.method,
		p.memo
	]);
	for (const co of SEED_COS) await sql.query(`insert into change_orders (line_item_id, title, amount_cents, status, reason)
       values ($1,$2,$3,$4,$5)`, [
		co.itemId,
		co.title,
		Math.round(co.amount * 100),
		co.status,
		co.reason
	]);
	try {
		await sql.query(`select setval('line_items_id_seq', (select max(id) from line_items))`);
		await sql.query(`select setval('payments_id_seq', coalesce((select max(id) from payments), 1))`);
		await sql.query(`select setval('change_orders_id_seq', coalesce((select max(id) from change_orders), 1))`);
	} catch {}
}
async function readSnapshot() {
	await ensureSeed();
	const sql = await getSql();
	const jobRow = (await sql`select * from job limit 1`)[0];
	if (!jobRow) throw new Error("Job row missing after seed");
	const categories = await sql`select * from categories order by sort_order, id`;
	const items = await sql`select * from line_items order by sort_order, id`;
	const payments = await sql`select * from payments order by paid_on desc, id desc`;
	const changeOrders = await sql`select * from change_orders order by created_at desc, id desc`;
	return {
		job: mapJob(jobRow),
		categories: categories.map(mapCategory),
		items: items.map(mapItem),
		payments: payments.map(mapPayment),
		changeOrders: changeOrders.map(mapCo)
	};
}
var loadJob_createServerFn_handler = createServerRpc({
	id: "3bac60ca03da2efa28a54ebb8810cb987813b713fca4551b830b2b706ce6fa02",
	name: "loadJob",
	filename: "src/lib/tracker/functions.ts"
}, (opts) => loadJob.__executeServer(opts));
var loadJob = createServerFn({ method: "GET" }).handler(loadJob_createServerFn_handler, async () => {
	return readSnapshot();
});
var jobPatch = object({
	name: string().min(1).max(120),
	address: string().max(160),
	city: string().max(80),
	beds: number().int().min(0).max(20),
	bathsTenths: number().int().min(0).max(100),
	sqft: number().int().min(0).max(1e5),
	stories: number().int().min(1).max(6),
	landCostCents: number().int().min(0),
	targetSaleCents: number().int().min(0),
	startDate: string().nullable(),
	targetCloseDate: string().nullable(),
	notes: string().max(2e3)
});
var updateJob_createServerFn_handler = createServerRpc({
	id: "54ccdd9c1a9ed2aa405219f44f36ff5162bcd5d358e443271f7bde8d206a41c4",
	name: "updateJob",
	filename: "src/lib/tracker/functions.ts"
}, (opts) => updateJob.__executeServer(opts));
var updateJob = createServerFn({ method: "POST" }).validator(jobPatch).handler(updateJob_createServerFn_handler, async ({ data }) => {
	await (await getSql()).query(`update job set
        name = $1, address = $2, city = $3, beds = $4, baths_tenths = $5,
        sqft = $6, stories = $7, land_cost_cents = $8, target_sale_cents = $9,
        start_date = $10, target_close_date = $11, notes = $12, updated_at = now()`, [
		data.name,
		data.address,
		data.city,
		data.beds,
		data.bathsTenths,
		data.sqft,
		data.stories,
		data.landCostCents,
		data.targetSaleCents,
		data.startDate,
		data.targetCloseDate,
		data.notes
	]);
	return readSnapshot();
});
var itemInput = object({
	categoryId: string().min(1),
	name: string().min(1).max(160),
	vendor: string().max(120),
	originalBudgetCents: number().int(),
	committedCents: number().int(),
	actualCents: number().int(),
	pctComplete: number().int().min(0).max(100),
	notes: string().max(2e3)
});
var createItem_createServerFn_handler = createServerRpc({
	id: "693cfca2af5dabe6da221e90cc9e867478a5019f138698e9253b3bf80307c7ef",
	name: "createItem",
	filename: "src/lib/tracker/functions.ts"
}, (opts) => createItem.__executeServer(opts));
var createItem = createServerFn({ method: "POST" }).validator(itemInput).handler(createItem_createServerFn_handler, async ({ data }) => {
	await (await getSql()).query(`insert into line_items (
        category_id, name, vendor, original_budget_cents, committed_cents,
        actual_cents, pct_complete, notes, sort_order
      ) values ($1,$2,$3,$4,$5,$6,$7,$8, coalesce((select max(sort_order)+1 from line_items), 1))`, [
		data.categoryId,
		data.name,
		data.vendor,
		data.originalBudgetCents,
		data.committedCents,
		data.actualCents,
		data.pctComplete,
		data.notes
	]);
	return readSnapshot();
});
var updateItem_createServerFn_handler = createServerRpc({
	id: "cd1f14e095d16b0b02632dd13a408be089a21e24d871abfff0d817c0d122a963",
	name: "updateItem",
	filename: "src/lib/tracker/functions.ts"
}, (opts) => updateItem.__executeServer(opts));
var updateItem = createServerFn({ method: "POST" }).validator(itemInput.extend({ id: number().int() })).handler(updateItem_createServerFn_handler, async ({ data }) => {
	await (await getSql()).query(`update line_items set
        category_id = $2, name = $3, vendor = $4, original_budget_cents = $5,
        committed_cents = $6, actual_cents = $7, pct_complete = $8, notes = $9
       where id = $1`, [
		data.id,
		data.categoryId,
		data.name,
		data.vendor,
		data.originalBudgetCents,
		data.committedCents,
		data.actualCents,
		data.pctComplete,
		data.notes
	]);
	return readSnapshot();
});
var deleteItem_createServerFn_handler = createServerRpc({
	id: "73a291a1510df05c18d6d04682d26ee365ab7a95cb211162d178e20113e9e3d9",
	name: "deleteItem",
	filename: "src/lib/tracker/functions.ts"
}, (opts) => deleteItem.__executeServer(opts));
var deleteItem = createServerFn({ method: "POST" }).validator(object({ id: number().int() })).handler(deleteItem_createServerFn_handler, async ({ data }) => {
	await (await getSql()).query(`delete from line_items where id = $1`, [data.id]);
	return readSnapshot();
});
var paymentInput = object({
	lineItemId: number().int(),
	paidOn: string().min(8),
	amountCents: number().int(),
	payee: string().max(120),
	method: _enum(PAYMENT_METHODS),
	memo: string().max(400)
});
var createPayment_createServerFn_handler = createServerRpc({
	id: "f75a4f3173f1518247dbc8722337f168a6d9671f44a6a03c04a9773b90e80f08",
	name: "createPayment",
	filename: "src/lib/tracker/functions.ts"
}, (opts) => createPayment.__executeServer(opts));
var createPayment = createServerFn({ method: "POST" }).validator(paymentInput).handler(createPayment_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	await sql.query(`insert into payments (line_item_id, paid_on, amount_cents, payee, method, memo)
       values ($1,$2,$3,$4,$5,$6)`, [
		data.lineItemId,
		data.paidOn,
		data.amountCents,
		data.payee,
		data.method,
		data.memo
	]);
	await sql.query(`update line_items set actual_cents = (
         select coalesce(sum(amount_cents), 0) from payments where line_item_id = $1
       ) where id = $1`, [data.lineItemId]);
	return readSnapshot();
});
var deletePayment_createServerFn_handler = createServerRpc({
	id: "c45e0e8d3da448c608598e0a830b55142ec2e8975bcbdcc12ca38e45d188771c",
	name: "deletePayment",
	filename: "src/lib/tracker/functions.ts"
}, (opts) => deletePayment.__executeServer(opts));
var deletePayment = createServerFn({ method: "POST" }).validator(object({ id: number().int() })).handler(deletePayment_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const itemId = (await sql`
      delete from payments where id = ${data.id} returning line_item_id
    `)[0]?.line_item_id;
	if (itemId) await sql.query(`update line_items set actual_cents = (
           select coalesce(sum(amount_cents), 0) from payments where line_item_id = $1
         ) where id = $1`, [itemId]);
	return readSnapshot();
});
var coInput = object({
	lineItemId: number().int().nullable(),
	title: string().min(1).max(160),
	amountCents: number().int(),
	status: _enum(CO_STATUSES),
	reason: string().max(800)
});
var createChangeOrder_createServerFn_handler = createServerRpc({
	id: "aa347e21e39ababd46faf20f1dae36af3838cb8d86d3cee0338e280ac19ac421",
	name: "createChangeOrder",
	filename: "src/lib/tracker/functions.ts"
}, (opts) => createChangeOrder.__executeServer(opts));
var createChangeOrder = createServerFn({ method: "POST" }).validator(coInput).handler(createChangeOrder_createServerFn_handler, async ({ data }) => {
	await (await getSql()).query(`insert into change_orders (line_item_id, title, amount_cents, status, reason)
       values ($1,$2,$3,$4,$5)`, [
		data.lineItemId,
		data.title,
		data.amountCents,
		data.status,
		data.reason
	]);
	return readSnapshot();
});
var updateChangeOrder_createServerFn_handler = createServerRpc({
	id: "de0f27001335cd1417be9135d3992f9cf3982d4550745934dde4980257429068",
	name: "updateChangeOrder",
	filename: "src/lib/tracker/functions.ts"
}, (opts) => updateChangeOrder.__executeServer(opts));
var updateChangeOrder = createServerFn({ method: "POST" }).validator(coInput.extend({ id: number().int() })).handler(updateChangeOrder_createServerFn_handler, async ({ data }) => {
	await (await getSql()).query(`update change_orders set line_item_id = $2, title = $3, amount_cents = $4, status = $5, reason = $6
       where id = $1`, [
		data.id,
		data.lineItemId,
		data.title,
		data.amountCents,
		data.status,
		data.reason
	]);
	return readSnapshot();
});
var deleteChangeOrder_createServerFn_handler = createServerRpc({
	id: "5074a5fdf99fbab62941a140e3e8273b0a573e070826e1470cd35ed20027915d",
	name: "deleteChangeOrder",
	filename: "src/lib/tracker/functions.ts"
}, (opts) => deleteChangeOrder.__executeServer(opts));
var deleteChangeOrder = createServerFn({ method: "POST" }).validator(object({ id: number().int() })).handler(deleteChangeOrder_createServerFn_handler, async ({ data }) => {
	await (await getSql()).query(`delete from change_orders where id = $1`, [data.id]);
	return readSnapshot();
});
//#endregion
export { createChangeOrder_createServerFn_handler, createItem_createServerFn_handler, createPayment_createServerFn_handler, deleteChangeOrder_createServerFn_handler, deleteItem_createServerFn_handler, deletePayment_createServerFn_handler, loadJob_createServerFn_handler, updateChangeOrder_createServerFn_handler, updateItem_createServerFn_handler, updateJob_createServerFn_handler };
