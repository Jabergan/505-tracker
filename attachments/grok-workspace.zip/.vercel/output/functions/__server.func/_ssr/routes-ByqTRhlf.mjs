import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as CO_STATUSES, r as PAYMENT_METHODS } from "./types-D9sHnxZK.mjs";
import { a as Plus, i as Settings2, n as TriangleAlert, o as Download, r as Trash2, t as X } from "../_libs/lucide-react.mjs";
import { a as createPayment, c as deletePayment, d as updateJob, i as createItem, l as updateChangeOrder, n as Route, o as deleteChangeOrder, r as createChangeOrder, s as deleteItem, u as updateItem } from "./router-CJa0JaGr.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ByqTRhlf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Badge({ className, tone = "neutral", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium", {
			neutral: "bg-sunken text-muted",
			ok: "bg-ok-soft text-ok",
			warn: "bg-warn-soft text-warn",
			bad: "bg-bad-soft text-bad"
		}[tone], className),
		children
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-opacity duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:pointer-events-none disabled:opacity-40 [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			outline: "border border-line-strong bg-surface text-ink hover:bg-sunken",
			ghost: "text-ink hover:bg-sunken",
			subtle: "bg-sunken text-ink hover:bg-line"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var Dialog = Dialog$1;
function DialogContent({ className, children, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed inset-x-0 bottom-0 z-50 flex max-h-dvh w-full max-w-lg flex-col overflow-hidden rounded-t-xl border border-line bg-surface shadow-lift", "sm:inset-auto sm:top-1/2 sm:left-1/2 sm:max-h-[90dvh] sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-xl", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3 border-b border-line px-5 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-serif text-xl leading-snug text-ink",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
				className: "flex size-11 shrink-0 items-center justify-center rounded-md text-muted hover:bg-sunken hover:text-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: "Close"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-y-auto px-5 py-4",
			children
		})]
	})] });
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-ink", "placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", "disabled:opacity-40", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-xs font-medium tracking-wide text-muted", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-24 w-full rounded-md border border-line bg-surface px-3 py-2 text-sm text-ink", "placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", className),
		...props
	});
}
function formatMoney(cents) {
	const sign = cents < 0 ? "-" : "";
	const abs = Math.abs(cents);
	const dollars = Math.floor(abs / 100);
	const rest = abs % 100;
	const body = dollars.toLocaleString("en-US");
	if (rest === 0) return `${sign}$${body}`;
	return `${sign}$${body}.${rest.toString().padStart(2, "0")}`;
}
function formatCompact(cents) {
	const sign = cents < 0 ? "-" : "";
	const abs = Math.abs(cents) / 100;
	if (abs >= 1e6) {
		const n = abs / 1e6;
		return `${sign}$${n.toFixed(n >= 10 ? 0 : 1)}M`;
	}
	if (abs >= 1e4) return `${sign}$${Math.round(abs / 1e3)}k`;
	if (abs >= 1e3) return `${sign}$${(abs / 1e3).toFixed(1)}k`;
	return formatMoney(cents);
}
function parseMoney(input) {
	const trimmed = input.trim().replace(/[$,\s]/g, "");
	if (!trimmed || trimmed === "-" || trimmed === ".") return null;
	const neg = trimmed.startsWith("(") && trimmed.endsWith(")");
	const raw = (neg ? trimmed.slice(1, -1) : trimmed).replace(/^\(/, "");
	const n = Number(raw);
	if (!Number.isFinite(n)) return null;
	const cents = Math.round(n * 100);
	return neg || trimmed.startsWith("-") ? -Math.abs(cents) : cents;
}
function formatPct(n, digits = 1) {
	if (!Number.isFinite(n)) return "—";
	return `${n.toFixed(digits)}%`;
}
function bathsLabel(tenths) {
	if (tenths % 10 === 0) return String(tenths / 10);
	return (tenths / 10).toFixed(1);
}
function isoToday() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function Field({ label, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("flex flex-col gap-1.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function NativeSelect({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn("flex h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-ink", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", className),
		...props
	});
}
function MoneyField({ label, valueCents, onChange, allowNegative = false }) {
	const [text, setText] = (0, import_react.useState)(() => formatEdit(valueCents));
	(0, import_react.useEffect)(() => {
		setText(formatEdit(valueCents));
	}, [valueCents]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			inputMode: "decimal",
			value: text,
			onChange: (e) => {
				const nextText = e.target.value;
				setText(nextText);
				const parsed = parseMoney(nextText);
				if (parsed === null) return;
				onChange(allowNegative ? parsed : Math.max(0, parsed));
			},
			onBlur: () => {
				const parsed = parseMoney(text);
				if (parsed === null) {
					setText(formatEdit(valueCents));
					return;
				}
				const next = allowNegative ? parsed : Math.max(0, parsed);
				onChange(next);
				setText(formatEdit(next));
			},
			className: "font-mono tabular-nums"
		})
	});
}
function formatEdit(cents) {
	return formatMoney(cents).replace("$", "");
}
function NotesField({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label: "Notes",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
			value,
			onChange: (e) => onChange(e.target.value),
			rows: 3
		})
	});
}
function approvedCoTotal(itemId, cos) {
	return cos.filter((c) => c.lineItemId === itemId && c.status === "approved").reduce((s, c) => s + c.amountCents, 0);
}
function pendingCoTotal(itemId, cos) {
	return cos.filter((c) => c.lineItemId === itemId && c.status === "pending").reduce((s, c) => s + c.amountCents, 0);
}
function rollupItem(item, cos) {
	const approvedCoCents = approvedCoTotal(item.id, cos);
	const pendingCoCents = pendingCoTotal(item.id, cos);
	const revisedBudgetCents = item.originalBudgetCents + approvedCoCents;
	const varianceCents = revisedBudgetCents - item.actualCents;
	const remainingCents = Math.max(0, revisedBudgetCents - item.actualCents);
	const forecastCents = item.pctComplete >= 100 ? item.actualCents : Math.max(revisedBudgetCents, item.actualCents);
	return {
		...item,
		approvedCoCents,
		pendingCoCents,
		revisedBudgetCents,
		varianceCents,
		remainingCents,
		forecastCents,
		overBudget: item.actualCents > revisedBudgetCents + 50
	};
}
function rollupJob(snap) {
	const items = snap.items.map((item) => rollupItem(item, snap.changeOrders));
	const catMap = new Map(snap.categories.map((c) => [c.id, c]));
	const categories = snap.categories.map((category) => {
		const rows = items.filter((i) => i.categoryId === category.id);
		const revisedBudgetCents = rows.reduce((s, r) => s + r.revisedBudgetCents, 0);
		const actualCents = rows.reduce((s, r) => s + r.actualCents, 0);
		return {
			category,
			revisedBudgetCents,
			actualCents,
			committedCents: rows.reduce((s, r) => s + r.committedCents, 0),
			forecastCents: rows.reduce((s, r) => s + r.forecastCents, 0),
			varianceCents: revisedBudgetCents - actualCents,
			remainingCents: Math.max(0, revisedBudgetCents - actualCents),
			itemCount: rows.length,
			overCount: rows.filter((r) => r.overBudget).length
		};
	});
	const byKind = {
		land: 0,
		soft: 0,
		hard: 0,
		contingency: 0
	};
	for (const row of categories) byKind[row.category.kind] += row.revisedBudgetCents;
	const revisedBudgetCents = items.reduce((s, r) => s + r.revisedBudgetCents, 0);
	const originalBudgetCents = items.reduce((s, r) => s + r.originalBudgetCents, 0);
	const actualCents = items.reduce((s, r) => s + r.actualCents, 0);
	const committedCents = items.reduce((s, r) => s + r.committedCents, 0);
	const forecastCents = items.reduce((s, r) => s + r.forecastCents, 0);
	const saleCents = snap.job.targetSaleCents;
	const profitAtBudgetCents = saleCents - revisedBudgetCents;
	const projectedProfitCents = saleCents - forecastCents;
	const contingency = categories.find((c) => c.category.kind === "contingency");
	const pending = snap.changeOrders.filter((c) => c.status === "pending");
	return {
		items,
		categories,
		totals: {
			saleCents,
			originalBudgetCents,
			revisedBudgetCents,
			actualCents,
			committedCents,
			forecastCents,
			remainingCents: Math.max(0, revisedBudgetCents - actualCents),
			varianceCents: revisedBudgetCents - actualCents,
			profitAtBudgetCents,
			projectedProfitCents,
			marginAtBudget: saleCents === 0 ? 0 : profitAtBudgetCents / saleCents * 100,
			projectedMargin: saleCents === 0 ? 0 : projectedProfitCents / saleCents * 100,
			spentOfBudget: revisedBudgetCents === 0 ? 0 : actualCents / revisedBudgetCents * 100,
			byKind,
			overCount: items.filter((i) => i.overBudget).length,
			pendingCoCount: pending.length,
			pendingCoCents: pending.reduce((s, c) => s + c.amountCents, 0),
			contingencyBudgetCents: contingency?.revisedBudgetCents ?? 0,
			contingencyDrawnCents: contingency?.actualCents ?? 0,
			...catMap.size >= 0 ? {} : {}
		}
	};
}
function itemStatus(item) {
	if (item.overBudget) return "over";
	if (item.pctComplete >= 100 || item.actualCents > 0 && item.remainingCents === 0) return "complete";
	if (item.actualCents > 0 || item.pctComplete > 0 || item.committedCents > 0) return "active";
	return "planned";
}
var TABS = [
	{
		id: "overview",
		label: "Overview"
	},
	{
		id: "budget",
		label: "Budget"
	},
	{
		id: "draws",
		label: "Draws"
	},
	{
		id: "changes",
		label: "Changes"
	}
];
var METHOD_LABEL = {
	check: "Check",
	ach: "ACH",
	wire: "Wire",
	card: "Card",
	cash: "Cash",
	retainage: "Retainage"
};
function JobApp({ initial }) {
	const [snap, setSnap] = (0, import_react.useState)(initial);
	const [tab, setTab] = (0, import_react.useState)("overview");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [jobOpen, setJobOpen] = (0, import_react.useState)(false);
	const [itemEdit, setItemEdit] = (0, import_react.useState)(null);
	const [payOpen, setPayOpen] = (0, import_react.useState)(false);
	const [coOpen, setCoOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setSnap(initial);
	}, [initial]);
	const rolled = (0, import_react.useMemo)(() => rollupJob(snap), [snap]);
	async function run(op) {
		setBusy(true);
		try {
			setSnap(await op());
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-line bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-5 px-4 py-5 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-serif text-4xl leading-none tracking-tight text-ink sm:text-5xl",
										children: "505"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs font-medium tracking-[0.22em] text-muted uppercase",
										children: "Spec house ledger"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-3 truncate text-sm text-muted",
										children: [
											snap.job.address,
											snap.job.city ? ` · ${snap.job.city}` : "",
											" · ",
											snap.job.beds,
											" bed /",
											" ",
											bathsLabel(snap.job.bathsTenths),
											" bath · ",
											snap.job.sqft.toLocaleString(),
											" sf"
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex shrink-0 gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Export CSV",
									onClick: () => exportCsv(snap, rolled.items),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Job settings",
									onClick: () => setJobOpen(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, {})
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiStrip, { totals: rolled.totals }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "-mb-px flex gap-1 overflow-x-auto",
							children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setTab(t.id),
								"aria-label": t.id === "changes" && rolled.totals.pendingCoCount > 0 ? `Changes, ${rolled.totals.pendingCoCount} pending` : t.label,
								className: cn("h-11 shrink-0 border-b-2 px-3 text-sm font-medium transition-colors duration-150", tab === t.id ? "border-accent text-ink" : "border-transparent text-muted hover:text-ink"),
								children: [t.label, t.id === "changes" && rolled.totals.pendingCoCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 font-mono text-xs text-warn",
									children: rolled.totals.pendingCoCount
								}) : null]
							}, t.id))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-6xl px-4 py-6 sm:px-6",
				children: [
					tab === "overview" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewPanel, {
						snap,
						rolled,
						onOpenItem: (item) => setItemEdit(item)
					}) : null,
					tab === "budget" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BudgetPanel, {
						snap,
						rolled,
						busy,
						onAdd: () => setItemEdit({
							categoryId: snap.categories[2]?.id ?? snap.categories[0]?.id,
							name: "",
							vendor: "",
							originalBudgetCents: 0,
							committedCents: 0,
							actualCents: 0,
							pctComplete: 0,
							notes: ""
						}),
						onEdit: setItemEdit
					}) : null,
					tab === "draws" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawsPanel, {
						snap,
						rolled,
						busy,
						onAdd: () => setPayOpen(true),
						onDelete: (id) => run(() => deletePayment({ data: { id } }))
					}) : null,
					tab === "changes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChangesPanel, {
						snap,
						busy,
						onAdd: () => setCoOpen(true),
						onStatus: (co, status) => run(() => updateChangeOrder({ data: {
							id: co.id,
							lineItemId: co.lineItemId,
							title: co.title,
							amountCents: co.amountCents,
							status,
							reason: co.reason
						} })),
						onDelete: (id) => run(() => deleteChangeOrder({ data: { id } }))
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobDialog, {
				open: jobOpen,
				onOpenChange: setJobOpen,
				snap,
				busy,
				onSave: (data) => run(async () => {
					const next = await updateJob({ data });
					setJobOpen(false);
					return next;
				})
			}),
			itemEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemDialog, {
				snap,
				draft: itemEdit,
				busy,
				onOpenChange: (open) => {
					if (!open) setItemEdit(null);
				},
				onSave: (data) => run(async () => {
					const next = data.id === void 0 ? await createItem({ data }) : await updateItem({ data: {
						...data,
						id: data.id
					} });
					setItemEdit(null);
					return next;
				}),
				onDelete: itemEdit.id ? () => run(async () => {
					const next = await deleteItem({ data: { id: itemEdit.id } });
					setItemEdit(null);
					return next;
				}) : void 0
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentDialog, {
				open: payOpen,
				onOpenChange: setPayOpen,
				snap,
				busy,
				onSave: (data) => run(async () => {
					const next = await createPayment({ data });
					setPayOpen(false);
					return next;
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChangeDialog, {
				open: coOpen,
				onOpenChange: setCoOpen,
				snap,
				busy,
				onSave: (data) => run(async () => {
					const next = await createChangeOrder({ data });
					setCoOpen(false);
					return next;
				})
			})
		]
	});
}
function KpiStrip({ totals }) {
	const profitPositive = totals.projectedProfitCents >= 0;
	const items = [
		{
			label: "List price",
			value: formatCompact(totals.saleCents),
			hint: "Target close"
		},
		{
			label: "Job cost",
			value: formatCompact(totals.revisedBudgetCents),
			hint: "Revised budget"
		},
		{
			label: "Spent",
			value: formatCompact(totals.actualCents),
			hint: formatPct(totals.spentOfBudget, 0) + " of budget"
		},
		{
			label: "Left to spend",
			value: formatCompact(totals.remainingCents),
			hint: "Against budget"
		},
		{
			label: "Projected profit",
			value: formatCompact(totals.projectedProfitCents),
			hint: formatPct(totals.projectedMargin, 1) + " margin",
			tone: profitPositive ? "ok" : "bad"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5",
		children: items.map((kpi) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg border border-line bg-bg px-3 py-3 sm:px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted uppercase",
					children: kpi.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("mt-1 font-mono text-xl font-medium tabular-nums sm:text-2xl", "tone" in kpi && kpi.tone === "ok" && "text-ok", "tone" in kpi && kpi.tone === "bad" && "text-bad"),
					children: kpi.value
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-xs text-subtle",
					children: kpi.hint
				})
			]
		}, kpi.label))
	});
}
function OverviewPanel({ snap, rolled, onOpenItem }) {
	const { totals, categories, items } = rolled;
	const sale = Math.max(totals.saleCents, 1);
	const segs = [
		{
			key: "land",
			label: "Land",
			cents: totals.byKind.land,
			className: "bg-accent"
		},
		{
			key: "hard",
			label: "Hard",
			cents: totals.byKind.hard,
			className: "bg-ink/70"
		},
		{
			key: "soft",
			label: "Soft",
			cents: totals.byKind.soft,
			className: "bg-ink/40"
		},
		{
			key: "cont",
			label: "Hold",
			cents: totals.byKind.contingency,
			className: "bg-warn"
		},
		{
			key: "profit",
			label: "Profit",
			cents: Math.max(0, totals.profitAtBudgetCents),
			className: "bg-ok"
		}
	];
	const overs = items.filter((i) => i.overBudget);
	const dates = [snap.job.startDate, snap.job.targetCloseDate].filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl text-ink",
							children: "Sale stack"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Every dollar of the list price, from dirt to hold to leftover."
						})] }), dates.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs text-subtle tabular-nums",
							children: [
								snap.job.startDate ?? "—",
								" → ",
								snap.job.targetCloseDate ?? "—"
							]
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex h-4 overflow-hidden rounded-full bg-sunken",
						children: segs.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("h-full", s.className),
							style: { width: `${s.cents / sale * 100}%` },
							title: `${s.label} ${formatMoney(s.cents)}`
						}, s.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 grid grid-cols-2 gap-2 sm:grid-cols-5",
						children: segs.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-full", s.className) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: s.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto font-mono text-xs tabular-nums",
									children: formatCompact(s.cents)
								})
							]
						}, s.key))
					})
				]
			}),
			snap.job.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-l-2 border-line-strong pl-4 text-sm leading-relaxed text-muted",
				children: snap.job.notes
			}) : null,
			overs.length > 0 || totals.pendingCoCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-line bg-surface p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "flex items-center gap-2 text-sm font-medium text-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 text-warn" }), "Watch list"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 flex flex-col gap-2",
					children: [overs.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onOpenItem(item),
						className: "flex w-full items-center justify-between gap-3 rounded-md px-2 py-2 text-left hover:bg-sunken",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-sm text-bad tabular-nums",
							children: formatMoney(item.varianceCents)
						})]
					}) }, item.id)), totals.pendingCoCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "px-2 py-1 text-sm text-muted",
						children: [
							totals.pendingCoCount,
							" change order",
							totals.pendingCoCount === 1 ? "" : "s",
							" pending ·",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono tabular-nums",
								children: formatMoney(totals.pendingCoCents)
							})
						]
					}) : null]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-line bg-surface p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl text-ink",
					children: "By trade"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-col gap-4",
					children: categories.map((row) => {
						const max = Math.max(row.revisedBudgetCents, row.actualCents, 1);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1.5 flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: row.category.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs text-muted tabular-nums",
								children: [
									formatCompact(row.actualCents),
									" / ",
									formatCompact(row.revisedBudgetCents)
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative h-2 rounded-full bg-sunken",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-y-0 left-0 rounded-full bg-line-strong",
								style: { width: `${row.revisedBudgetCents / max * 100}%` }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("absolute inset-y-0 left-0 rounded-full", row.overCount > 0 ? "bg-bad" : "bg-accent"),
								style: { width: `${Math.min(100, row.actualCents / max * 100)}%` }
							})]
						})] }, row.category.id);
					})
				})]
			})
		]
	});
}
function BudgetPanel({ snap, rolled, busy, onAdd, onEdit }) {
	const [q, setQ] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const query = q.trim().toLowerCase();
	const visible = rolled.items.filter((item) => {
		const status = itemStatus(item);
		if (filter !== "all" && status !== filter) return false;
		if (!query) return true;
		const cat = snap.categories.find((c) => c.id === item.categoryId)?.name ?? "";
		return `${item.name} ${item.vendor} ${cat}`.toLowerCase().includes(query);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Search lines, vendors…",
						className: "sm:max-w-xs"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1",
						children: [
							"all",
							"over",
							"active",
							"planned",
							"complete"
						].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setFilter(id),
							className: cn("h-9 rounded-full px-3 text-xs font-medium capitalize", filter === id ? "bg-accent text-accent-fg" : "bg-sunken text-muted"),
							children: id
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "sm:ml-auto",
						onClick: onAdd,
						disabled: busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add line"]
					})
				]
			}),
			snap.categories.map((cat) => {
				const rows = visible.filter((i) => i.categoryId === cat.id);
				if (rows.length === 0) return null;
				const sub = rolled.categories.find((c) => c.category.id === cat.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "overflow-hidden rounded-xl border border-line bg-surface",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3 border-b border-line px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium tracking-wide uppercase",
							children: cat.name
						}), sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs text-muted tabular-nums",
							children: [
								formatMoney(sub.actualCents),
								" / ",
								formatMoney(sub.revisedBudgetCents)
							]
						}) : null]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-line",
						children: rows.map((item) => {
							const status = itemStatus(item);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onEdit(item),
								className: "flex w-full flex-col gap-1 px-4 py-3 text-left hover:bg-sunken sm:flex-row sm:items-center sm:gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm font-medium",
											children: item.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-xs text-subtle",
										children: [item.vendor || "No vendor", item.approvedCoCents !== 0 ? ` · CO ${formatMoney(item.approvedCoCents)}` : ""]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid w-full grid-cols-3 gap-2 font-mono text-xs tabular-nums sm:w-auto sm:min-w-80 sm:grid-cols-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mr-1 text-subtle",
												children: "Bud"
											}), formatMoney(item.revisedBudgetCents)]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mr-1 text-subtle",
											children: "Act"
										}), formatMoney(item.actualCents)] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: item.varianceCents < 0 ? "text-bad" : "text-ok",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mr-1 text-subtle",
												children: "Var"
											}), formatMoney(item.varianceCents)]
										})
									]
								})]
							}) }, item.id);
						})
					})]
				}, cat.id);
			}),
			visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-dashed border-line-strong px-4 py-10 text-center text-sm text-muted",
				children: "No lines match that filter."
			}) : null
		]
	});
}
function StatusBadge({ status }) {
	if (status === "over") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: "bad",
		children: "Over"
	});
	if (status === "complete") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: "ok",
		children: "Done"
	});
	if (status === "active") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: "warn",
		children: "Active"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Planned" });
}
function DrawsPanel({ snap, rolled, busy, onAdd, onDelete }) {
	const nameOf = (id) => rolled.items.find((i) => i.id === id)?.name ?? "Line";
	const total = snap.payments.reduce((s, p) => s + p.amountCents, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					snap.payments.length,
					" draws ·",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono tabular-nums text-ink",
						children: formatMoney(total)
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: onAdd,
				disabled: busy,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Log draw"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "overflow-hidden rounded-xl border border-line bg-surface divide-y divide-line",
			children: [snap.payments.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-start gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline gap-x-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-sm tabular-nums",
							children: formatMoney(p.amountCents)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: p.payee
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-subtle",
						children: [
							p.paidOn,
							" · ",
							nameOf(p.lineItemId),
							" · ",
							METHOD_LABEL[p.method],
							p.memo ? ` · ${p.memo}` : ""
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Delete draw",
					disabled: busy,
					onClick: () => onDelete(p.id),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
				})]
			}, p.id)), snap.payments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "px-4 py-10 text-center text-sm text-muted",
				children: "No draws yet."
			}) : null]
		})]
	});
}
function ChangesPanel({ snap, busy, onAdd, onStatus, onDelete }) {
	const nameOf = (id) => id === null ? "Unassigned" : snap.items.find((i) => i.id === id)?.name ?? "Line";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Approved COs rewrite the working budget."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: onAdd,
				disabled: busy,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "New CO"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "flex flex-col gap-3",
			children: [snap.changeOrders.map((co) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: co.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: co.status === "approved" ? "ok" : co.status === "rejected" ? "neutral" : "warn",
									children: co.status
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-subtle",
								children: nameOf(co.lineItemId)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("font-mono text-sm tabular-nums", co.amountCents < 0 ? "text-ok" : "text-ink"),
							children: formatMoney(co.amountCents)
						})]
					}),
					co.reason ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: co.reason
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [
							co.status !== "approved" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => onStatus(co, "approved"),
								children: "Approve"
							}) : null,
							co.status !== "rejected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								disabled: busy,
								onClick: () => onStatus(co, "rejected"),
								children: "Reject"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								disabled: busy,
								onClick: () => onDelete(co.id),
								className: "ml-auto text-bad hover:bg-bad-soft",
								children: "Remove"
							})
						]
					})
				]
			}, co.id)), snap.changeOrders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "rounded-xl border border-dashed border-line-strong px-4 py-10 text-center text-sm text-muted",
				children: "No change orders."
			}) : null]
		})]
	});
}
function JobDialog({ open, onOpenChange, snap, busy, onSave }) {
	const j = snap.job;
	const [form, setForm] = (0, import_react.useState)({
		name: j.name,
		address: j.address,
		city: j.city,
		beds: j.beds,
		bathsTenths: j.bathsTenths,
		sqft: j.sqft,
		stories: j.stories,
		landCostCents: j.landCostCents,
		targetSaleCents: j.targetSaleCents,
		startDate: j.startDate ?? "",
		targetCloseDate: j.targetCloseDate ?? "",
		notes: j.notes
	});
	(0, import_react.useEffect)(() => {
		if (open) setForm({
			name: j.name,
			address: j.address,
			city: j.city,
			beds: j.beds,
			bathsTenths: j.bathsTenths,
			sqft: j.sqft,
			stories: j.stories,
			landCostCents: j.landCostCents,
			targetSaleCents: j.targetSaleCents,
			startDate: j.startDate ?? "",
			targetCloseDate: j.targetCloseDate ?? "",
			notes: j.notes
		});
	}, [open, j]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			title: "Job file",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3",
				onSubmit: (e) => {
					e.preventDefault();
					onSave({
						...form,
						startDate: form.startDate || null,
						targetCloseDate: form.targetCloseDate || null
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.name,
							onChange: (e) => setForm({
								...form,
								name: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Address",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.address,
								onChange: (e) => setForm({
									...form,
									address: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "City",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.city,
								onChange: (e) => setForm({
									...form,
									city: e.target.value
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Beds",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									value: form.beds,
									onChange: (e) => setForm({
										...form,
										beds: Number(e.target.value)
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Baths",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
									value: String(form.bathsTenths),
									onChange: (e) => setForm({
										...form,
										bathsTenths: Number(e.target.value)
									}),
									children: [
										10,
										15,
										20,
										25,
										30,
										35,
										40,
										45,
										50
									].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: n,
										children: n % 10 === 0 ? n / 10 : (n / 10).toFixed(1)
									}, n))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Sq ft",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									value: form.sqft,
									onChange: (e) => setForm({
										...form,
										sqft: Number(e.target.value)
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Stories",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 1,
									value: form.stories,
									onChange: (e) => setForm({
										...form,
										stories: Number(e.target.value)
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
							label: "Land cost",
							valueCents: form.landCostCents,
							onChange: (landCostCents) => setForm({
								...form,
								landCostCents
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
							label: "Target sale",
							valueCents: form.targetSaleCents,
							onChange: (targetSaleCents) => setForm({
								...form,
								targetSaleCents
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Start",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: form.startDate,
								onChange: (e) => setForm({
									...form,
									startDate: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Target close",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: form.targetCloseDate,
								onChange: (e) => setForm({
									...form,
									targetCloseDate: e.target.value
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesField, {
						value: form.notes,
						onChange: (notes) => setForm({
							...form,
							notes
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						className: "mt-2",
						children: "Save job"
					})
				]
			})
		})
	});
}
function ItemDialog({ snap, draft, busy, onOpenChange, onSave, onDelete }) {
	const [form, setForm] = (0, import_react.useState)({
		categoryId: draft.categoryId ?? snap.categories[0]?.id ?? "hard",
		name: draft.name ?? "",
		vendor: draft.vendor ?? "",
		originalBudgetCents: draft.originalBudgetCents ?? 0,
		committedCents: draft.committedCents ?? 0,
		actualCents: draft.actualCents ?? 0,
		pctComplete: draft.pctComplete ?? 0,
		notes: draft.notes ?? ""
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			title: draft.id ? "Edit line" : "New line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3",
				onSubmit: (e) => {
					e.preventDefault();
					if (!form.name.trim()) return;
					onSave({
						...form,
						id: draft.id,
						name: form.name.trim()
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Category",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
							value: form.categoryId,
							onChange: (e) => setForm({
								...form,
								categoryId: e.target.value
							}),
							children: snap.categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c.id,
								children: c.name
							}, c.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.name,
							onChange: (e) => setForm({
								...form,
								name: e.target.value
							}),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Vendor",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.vendor,
							onChange: (e) => setForm({
								...form,
								vendor: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
								label: "Original budget",
								valueCents: form.originalBudgetCents,
								onChange: (originalBudgetCents) => setForm({
									...form,
									originalBudgetCents
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
								label: "Committed",
								valueCents: form.committedCents,
								onChange: (committedCents) => setForm({
									...form,
									committedCents
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
								label: "Actual",
								valueCents: form.actualCents,
								onChange: (actualCents) => setForm({
									...form,
									actualCents
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Complete ${form.pctComplete}%`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "range",
							min: 0,
							max: 100,
							value: form.pctComplete,
							onChange: (e) => setForm({
								...form,
								pctComplete: Number(e.target.value)
							}),
							className: "h-11 w-full accent-accent"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesField, {
						value: form.notes,
						onChange: (notes) => setForm({
							...form,
							notes
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: busy,
							className: "flex-1",
							children: "Save line"
						}), onDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							disabled: busy,
							onClick: onDelete,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
						}) : null]
					})
				]
			})
		})
	});
}
function PaymentDialog({ open, onOpenChange, snap, busy, onSave }) {
	const [form, setForm] = (0, import_react.useState)({
		lineItemId: snap.items[0]?.id ?? 0,
		paidOn: isoToday(),
		amountCents: 0,
		payee: "",
		method: "check",
		memo: ""
	});
	(0, import_react.useEffect)(() => {
		if (open) setForm({
			lineItemId: snap.items[0]?.id ?? 0,
			paidOn: isoToday(),
			amountCents: 0,
			payee: "",
			method: "check",
			memo: ""
		});
	}, [open, snap.items]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			title: "Log a draw",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3",
				onSubmit: (e) => {
					e.preventDefault();
					if (!form.lineItemId || form.amountCents === 0) return;
					onSave(form);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Against line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
							value: String(form.lineItemId),
							onChange: (e) => setForm({
								...form,
								lineItemId: Number(e.target.value)
							}),
							children: snap.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.name
							}, item.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Date",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: form.paidOn,
								onChange: (e) => setForm({
									...form,
									paidOn: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
							label: "Amount",
							valueCents: form.amountCents,
							onChange: (amountCents) => setForm({
								...form,
								amountCents
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Payee",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.payee,
							onChange: (e) => setForm({
								...form,
								payee: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Method",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
							value: form.method,
							onChange: (e) => setForm({
								...form,
								method: e.target.value
							}),
							children: PAYMENT_METHODS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: m,
								children: METHOD_LABEL[m]
							}, m))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Memo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.memo,
							onChange: (e) => setForm({
								...form,
								memo: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						className: "mt-2",
						children: "Save draw"
					})
				]
			})
		})
	});
}
function ChangeDialog({ open, onOpenChange, snap, busy, onSave }) {
	const [form, setForm] = (0, import_react.useState)({
		lineItemId: snap.items[0]?.id ?? 0,
		title: "",
		amountCents: 0,
		status: "pending",
		reason: ""
	});
	(0, import_react.useEffect)(() => {
		if (open) setForm({
			lineItemId: snap.items[0]?.id ?? 0,
			title: "",
			amountCents: 0,
			status: "pending",
			reason: ""
		});
	}, [open, snap.items]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			title: "Change order",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3",
				onSubmit: (e) => {
					e.preventDefault();
					if (!form.title.trim()) return;
					onSave({
						...form,
						title: form.title.trim()
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Title",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.title,
							onChange: (e) => setForm({
								...form,
								title: e.target.value
							}),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
							value: String(form.lineItemId),
							onChange: (e) => setForm({
								...form,
								lineItemId: Number(e.target.value)
							}),
							children: snap.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.name
							}, item.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
						label: "Amount (negative = credit)",
						valueCents: form.amountCents,
						allowNegative: true,
						onChange: (amountCents) => setForm({
							...form,
							amountCents
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Status",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
							value: form.status,
							onChange: (e) => setForm({
								...form,
								status: e.target.value
							}),
							children: CO_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								children: s
							}, s))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesField, {
						value: form.reason,
						onChange: (reason) => setForm({
							...form,
							reason
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						className: "mt-2",
						children: "Save CO"
					})
				]
			})
		})
	});
}
function exportCsv(snap, items) {
	const header = [
		"Category",
		"Line",
		"Vendor",
		"Original",
		"Approved COs",
		"Budget",
		"Committed",
		"Actual",
		"Variance",
		"Complete %",
		"Notes"
	];
	const catName = (id) => snap.categories.find((c) => c.id === id)?.name ?? id;
	const csv = [header, ...items.map((item) => [
		catName(item.categoryId),
		item.name,
		item.vendor,
		(item.originalBudgetCents / 100).toFixed(2),
		(item.approvedCoCents / 100).toFixed(2),
		(item.revisedBudgetCents / 100).toFixed(2),
		(item.committedCents / 100).toFixed(2),
		(item.actualCents / 100).toFixed(2),
		(item.varianceCents / 100).toFixed(2),
		String(item.pctComplete),
		item.notes.replaceAll("\"", "\"\"")
	])].map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
	const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = "505-budget.csv";
	a.click();
	URL.revokeObjectURL(url);
}
function Home() {
	const data = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobApp, { initial: data });
}
//#endregion
export { Home as component };
